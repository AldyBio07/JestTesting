const homePage = () => {
    return (
        <div>
            <h1>Homepage</h1>
        </div>
    );
}

export default homePage;