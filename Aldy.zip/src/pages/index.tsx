import React from "react";

const Home = () => {
  return (
    <div>
      <button>test</button>
    </div>
  );
};

export default Home;