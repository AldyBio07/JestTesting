import homePage from "@/pages/homepage";
import { render, screen } from "@testing-library/react";

describe("input Component", () => {
    it("render input text", () => {
        const { container } = render(homePage());
        expect(screen.getByText("Homepage")).toBeInTheDocument();
    });
})