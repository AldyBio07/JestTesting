export interface InputProps{
    type: string;
    value: string;
}